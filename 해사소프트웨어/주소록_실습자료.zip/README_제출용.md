# Claude Code로 주소록 웹앱 다시 만들기 — 9주차 웹프로젝트 재도전

- 과목: (직접 작성)  ·  학번/이름: (직접 작성)
- 사용 도구: VS Code, Claude Code, Windows PowerShell, Python, Flask, SQLite, pytest

## 1. 9주차 웹프로젝트의 문제점과 해결

| 9주차에 생긴 문제 | 원인 | 이번에 바꾼 방법 |
|---|---|---|
| 첫 커밋이 끝까지 실패 | Git 이름·이메일 미설정 | 0단계에서 `git config --global` 먼저 설정 |
| `source` 명령 오류 | 교안 명령이 Mac 기준 | 모든 명령을 Windows PowerShell 기준으로 통일 |
| 가상환경 활성화 오류 | PowerShell 실행 정책이 스크립트 차단 | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
| 교안의 승인 화면이 안 나옴 | Claude Code 모드가 auto 등으로 제각각 | 0단계에서 manual 모드로 맞춤 |
| 프롬프트에 반응 없음 | 로그인 만료 | 0단계에서 `/login` 확인 |
| 포트 5000 사용 중 오류 | Claude가 서버를 백그라운드로 실행, 터미널 1개 사용 | 터미널 2개(Claude/서버) + CLAUDE.md "서버 실행 금지" + 승인 화면에서 No |
| `no such table` 오류 | DB 초기화 명령 누락 | 앱 시작 시 `CREATE TABLE IF NOT EXISTS`로 자동 생성 |
| 성공했는지 판단 불가 | 결과가 안 보이는 단계, 모호한 성공 기준 | 0~8단계로 재구성, 단계마다 성공 확인 체크 |

## 2. 완성한 기능

- 연락처 등록(이름 필수 검사), 목록, 검색, 수정, 삭제
- 모든 SQL은 `?` 파라미터 바인딩, UPDATE·DELETE는 `WHERE id = ?`
- pytest 테스트 (임시 DB 사용, SQL 인젝션 문자열 테스트 포함)

### 실행 방법 (Windows PowerShell)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py              # http://127.0.0.1:5000
python -m pytest -v        # 테스트
```

## 3. 단계별 진행과 중요 화면

> 각 캡처 아래 "중요한 이유"는 제가 실습하면서 판단한 내용입니다.

### 0단계 · 준비 체크리스트
![준비](screenshots/00_setup.png)
**중요한 이유:** 9주차 커밋 실패의 원인이던 Git 사용자 설정과, Claude용·서버용 터미널 2개를 먼저 준비한 화면입니다.

![로그인과 manual 모드](screenshots/01_login_manual.png)
**중요한 이유:** 로그인 상태와 manual 모드를 확인해야 이후 단계에서 승인 화면이 나오고 Claude의 작업을 직접 검토할 수 있습니다.

### 1단계 · Plan 모드로 설계
![Plan 모드](screenshots/02_plan.png)
**중요한 이유:** `IF NOT EXISTS`는 이미 있는 테이블을 바꾸지 않으므로, 나중에 칸을 추가하지 않도록 contacts 테이블의 모든 칸을 처음에 설계했습니다.

### 2단계 · 골격과 첫 화면
![CLAUDE.md](screenshots/03_claude_md.png)
**중요한 이유:** CLAUDE.md에 "서버는 Claude가 실행하지 않는다", "SQL은 ? 바인딩" 같은 규칙을 적어 모든 단계에 적용했습니다.

![첫 화면](screenshots/04_first_screen.png)
**중요한 이유:** 서버를 터미널 ②에서 직접 실행해 `(.venv)` 활성화와 `GET /` 요청 기록을 눈으로 확인했습니다.

### 3단계 · DB와 등록·목록
![승인 화면 - CREATE TABLE IF NOT EXISTS](screenshots/05_approve_create_table.png)
**중요한 이유:** 승인 전에 diff에서 `CREATE TABLE IF NOT EXISTS`와 `?` 바인딩을 확인했습니다. 재시작해도 데이터가 유지되고 SQL 인젝션을 막는 핵심입니다.

![등록과 목록](screenshots/06_add_list.png)
![이름 빈칸 검사](screenshots/07_name_required.png)
**중요한 이유:** 브라우저 동작과 서버 로그(`POST /add` → `GET /`)를 함께 보며 요청·응답 흐름을 확인했고, 잘못된 입력이 저장되지 않는 것을 확인했습니다.

### 4단계 · 검색
![검색](screenshots/08_search.png)
**중요한 이유:** 검색어를 SQL에 직접 붙이지 않고 `LIKE ?`로 바인딩해 처리했습니다.

### 5~6단계 · 수정과 삭제
![UPDATE WHERE](screenshots/09_approve_update.png)
![DELETE WHERE](screenshots/10_approve_delete.png)
**중요한 이유:** `WHERE id = ?`가 빠지면 모든 연락처가 바뀌거나 지워집니다. 승인 화면에서 이 조건을 직접 확인하고 허락했습니다.

### 7단계 · 화면 다듬기
![완성 화면](screenshots/11_final_screen.png)

### 8단계 · 테스트와 커밋 이력
![pytest](screenshots/12_pytest.png)
![git log](screenshots/13_git_log.png)
**중요한 이유:** 테스트로 기능을 자동 검증했고, 단계별 커밋 이력으로 0~8단계를 실제로 진행한 과정을 확인할 수 있습니다.

### 오류를 만나고 해결한 과정
![오류](screenshots/14_error.png)
![해결](screenshots/15_error_fix.png)
**무슨 오류였고 어떻게 해결했나:** (직접 작성)

## 4. 반복 연습 기록

![반복 연습 폴더](screenshots/20_repeat_folders.png)
![2회차 커밋 이력](screenshots/21_round2_git_log.png)

| 회차 | 날짜 | 걸린 시간 | 방법 | 막힌 곳 | 해결 방법 | 1회차와 달라진 점 |
|---|---|---|---|---|---|---|
| 1회차 | (직접 작성) | | 가이드 프롬프트 사용 | | | - |
| 2회차 | | | 프롬프트를 내 말로 작성 | | | |
| 3회차 | | | (선택) 기능 추가 | | | |

## 5. 배운 점

(직접 작성 — 예: 승인 화면에서 무엇을 확인해야 하는지, CLAUDE.md 규칙의 효과, 오류를 Claude에게 정확히 전달하는 방법 등)
