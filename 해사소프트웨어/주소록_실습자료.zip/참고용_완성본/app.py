"""주소록 웹앱 (Flask + SQLite)

- 앱이 켜질 때 contacts 테이블이 없으면 자동으로 만든다 (CREATE TABLE IF NOT EXISTS).
- 모든 SQL은 ? 자리표시자(파라미터 바인딩)로 값을 넘긴다.
- 서버 실행: 터미널 ②에서  python app.py
"""
import os
import re
import sqlite3

from flask import Flask, flash, g, redirect, render_template, request, url_for

SCHEMA = """
CREATE TABLE IF NOT EXISTS contacts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    phone      TEXT    NOT NULL DEFAULT '',
    email      TEXT    NOT NULL DEFAULT '',
    memo       TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
"""

PHONE_RE = re.compile(r"^[0-9\-+ ]{0,20}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY="dev-only-change-me",
        DATABASE=os.path.join(app.root_path, "addressbook.db"),
    )
    if test_config:
        app.config.update(test_config)

    # ---------- DB 도우미 ----------
    def get_db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def close_db(exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    def init_db():
        db = sqlite3.connect(app.config["DATABASE"])
        db.executescript(SCHEMA)
        db.commit()
        db.close()

    init_db()  # 앱 시작 시 자동 생성 (별도 init-db 명령 없음)

    def validate(form):
        """입력값을 정리하고 오류 메시지 목록을 돌려준다."""
        data = {k: form.get(k, "").strip() for k in ("name", "phone", "email", "memo")}
        errors = []
        if not data["name"]:
            errors.append("이름은 꼭 입력해 주세요.")
        if len(data["name"]) > 50:
            errors.append("이름은 50자 이하로 입력해 주세요.")
        if data["phone"] and not PHONE_RE.match(data["phone"]):
            errors.append("전화번호는 숫자, -, +, 공백만 쓸 수 있어요.")
        if data["email"] and not EMAIL_RE.match(data["email"]):
            errors.append("이메일 형식이 올바르지 않아요.")
        if len(data["memo"]) > 200:
            errors.append("메모는 200자 이하로 입력해 주세요.")
        return data, errors

    # ---------- 화면 ----------
    @app.get("/")
    def index():
        q = request.args.get("q", "").strip()
        db = get_db()
        if q:
            like = f"%{q}%"
            rows = db.execute(
                "SELECT * FROM contacts WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? "
                "ORDER BY name",
                (like, like, like),
            ).fetchall()
        else:
            rows = db.execute("SELECT * FROM contacts ORDER BY name").fetchall()
        total = db.execute("SELECT COUNT(*) FROM contacts").fetchone()[0]
        return render_template("index.html", contacts=rows, q=q, total=total, form={})

    @app.post("/add")
    def add():
        data, errors = validate(request.form)
        if errors:
            for e in errors:
                flash(e, "error")
            db = get_db()
            rows = db.execute("SELECT * FROM contacts ORDER BY name").fetchall()
            total = len(rows)
            return render_template("index.html", contacts=rows, q="", total=total, form=data), 400
        db = get_db()
        db.execute(
            "INSERT INTO contacts (name, phone, email, memo) VALUES (?, ?, ?, ?)",
            (data["name"], data["phone"], data["email"], data["memo"]),
        )
        db.commit()
        flash(f"'{data['name']}' 님을 추가했어요.", "ok")
        return redirect(url_for("index"))

    @app.route("/edit/<int:contact_id>", methods=["GET", "POST"])
    def edit(contact_id):
        db = get_db()
        row = db.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()
        if row is None:
            flash("해당 연락처를 찾을 수 없어요.", "error")
            return redirect(url_for("index"))
        if request.method == "POST":
            data, errors = validate(request.form)
            if errors:
                for e in errors:
                    flash(e, "error")
                return render_template("edit.html", c=row, form=data), 400
            db.execute(
                "UPDATE contacts SET name = ?, phone = ?, email = ?, memo = ? WHERE id = ?",
                (data["name"], data["phone"], data["email"], data["memo"], contact_id),
            )
            db.commit()
            flash(f"'{data['name']}' 님 정보를 수정했어요.", "ok")
            return redirect(url_for("index"))
        return render_template("edit.html", c=row, form=dict(row))

    @app.post("/delete/<int:contact_id>")
    def delete(contact_id):
        db = get_db()
        row = db.execute("SELECT name FROM contacts WHERE id = ?", (contact_id,)).fetchone()
        if row is None:
            flash("해당 연락처를 찾을 수 없어요.", "error")
        else:
            db.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
            db.commit()
            flash(f"'{row['name']}' 님을 삭제했어요.", "ok")
        return redirect(url_for("index"))

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
