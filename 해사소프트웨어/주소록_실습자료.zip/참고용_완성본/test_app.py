"""주소록 앱 테스트 — 실제 addressbook.db 대신 매번 새 임시 DB를 쓴다.
실행: python -m pytest -v
"""
import pytest

from app import create_app


@pytest.fixture
def client(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    return app.test_client()


def add(client, **kw):
    data = {"name": "", "phone": "", "email": "", "memo": ""}
    data.update(kw)
    return client.post("/add", data=data, follow_redirects=True)


def test_첫화면_열림(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "주소록" in r.get_data(as_text=True)


def test_등록하면_목록에_보임(client):
    r = add(client, name="김해양", phone="010-1111-2222", email="kim@kmou.ac.kr")
    html = r.get_data(as_text=True)
    assert "김해양" in html and "010-1111-2222" in html


def test_이름_비우면_저장_안됨(client):
    r = client.post("/add", data={"name": "  ", "phone": "010"})
    assert r.status_code == 400
    assert "이름은 꼭 입력" in r.get_data(as_text=True)
    assert "0명" in client.get("/").get_data(as_text=True)


def test_잘못된_이메일_거부(client):
    r = client.post("/add", data={"name": "박보안", "email": "not-an-email"})
    assert r.status_code == 400


def test_검색(client):
    add(client, name="김해양")
    add(client, name="이선박")
    html = client.get("/?q=선박").get_data(as_text=True)
    assert "이선박" in html and "김해양" not in html


def test_수정(client):
    add(client, name="김해양")
    r = client.post("/edit/1", data={"name": "김해양", "phone": "010-9999-0000"},
                    follow_redirects=True)
    assert "010-9999-0000" in r.get_data(as_text=True)


def test_삭제는_해당_연락처만(client):
    add(client, name="김해양")
    add(client, name="이선박")
    r = client.post("/delete/1", follow_redirects=True)
    html = r.get_data(as_text=True)
    assert "이선박" in html and "1명" in html


def test_SQL_인젝션_문자열도_그냥_글자로_저장(client):
    evil = "x'); DROP TABLE contacts; --"
    add(client, name=evil)
    html = client.get("/").get_data(as_text=True)
    assert "1명" in html  # 테이블이 지워지지 않았다


def test_앱_재시작해도_데이터_유지(tmp_path):
    cfg = {"TESTING": True, "DATABASE": str(tmp_path / "keep.db")}
    add(create_app(cfg).test_client(), name="김해양")
    html = create_app(cfg).test_client().get("/").get_data(as_text=True)
    assert "김해양" in html
