# CLAUDE.md — 주소록 웹앱 프로젝트 규칙

## 프로젝트
- Flask + SQLite로 만드는 주소록 웹앱 (9주차 웹프로젝트 재도전)
- 파일 구성: app.py, templates/, static/, test_app.py, requirements.txt, README.md

## 실행 환경
- Windows PowerShell 기준으로 명령을 안내한다. (Mac 명령은 괄호로만 덧붙인다)
- 가상환경: `.\.venv\Scripts\Activate.ps1`
- 파이썬: `python` (python3 아님)

## 반드시 지킬 규칙
1. **서버(python app.py)는 Claude가 직접 실행하지 않는다.** 실행 명령만 알려 준다. 서버는 학생이 터미널 ②에서 직접 켜고 끈다.
2. pytest 같은 "실행하고 끝나는" 명령은 실행해도 된다.
3. DB 테이블은 앱 시작 시 `CREATE TABLE IF NOT EXISTS`로 자동 생성한다. 별도 init-db 명령을 만들지 않는다.
4. SQL에 값을 넣을 때는 반드시 `?` 파라미터 바인딩을 쓴다. 문자열 더하기·f-string으로 SQL을 만들지 않는다.
5. UPDATE·DELETE에는 반드시 `WHERE id = ?` 조건을 붙인다.
6. 테이블 구조(contacts)는 1단계 설계대로 유지하고, 요청 없이 바꾸지 않는다.
7. 한 단계가 끝나면 변경 내용을 요약하고, 학생이 확인한 뒤 `git commit` 한다. 커밋 메시지는 "N단계: 내용" 형식.
8. 새 패키지를 설치하기 전에는 이유를 먼저 말한다.
9. 답변은 한국어로, 초보자가 따라 할 수 있게 짧게 쓴다.

## contacts 테이블 (1단계 설계)
| 칸 | 타입 | 설명 |
|---|---|---|
| id | INTEGER PK AUTOINCREMENT | 번호 |
| name | TEXT NOT NULL | 이름 (필수) |
| phone | TEXT | 전화번호 |
| email | TEXT | 이메일 |
| memo | TEXT | 메모 |
| created_at | TEXT | 등록 시각 |
